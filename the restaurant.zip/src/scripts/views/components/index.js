/* header */
import './nav-bar';
import './banner-info';

/* konten */
import './resto-list';
import './resto-item';

/* halaman */
import './resto-detail';
import './resto-info';
import './resto-review';

/* footer */
import './footer-info';
